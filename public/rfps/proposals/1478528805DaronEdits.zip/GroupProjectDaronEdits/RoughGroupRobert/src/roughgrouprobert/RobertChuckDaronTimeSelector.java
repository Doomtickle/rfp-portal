/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.roughgrouprobert;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory.ListSpinnerValueFactory;
import javafx.scene.layout.HBox;

/**
 *This class constructs the timeBox and provides
 *get methods to retrieve a concatenated string of the selected time or
 *of the individual parts of the selected time.
 */
public class RobertChuckDaronTimeSelector {
    
    private SimpleStringProperty hour = new SimpleStringProperty();
    private SimpleStringProperty minute = new SimpleStringProperty();
    private SimpleStringProperty meridiem = new SimpleStringProperty();
    private SimpleStringProperty militaryTime = new SimpleStringProperty();
    private String time;
   
    
    private final ObservableList hoursList = FXCollections.observableArrayList("1","2","3","4","5","6","7","8","9","10","11","12");
    private final ChoiceBox hourBox = new ChoiceBox(hoursList);
    
    private final ObservableList minuteList = FXCollections.observableArrayList("00","05","10","15","20","25","30","35","40","45","50","55");
    private final ChoiceBox minuteBox = new ChoiceBox(minuteList);
            
    private final ObservableList meridiemList = FXCollections.observableArrayList("","AM","PM");
    private final ListSpinnerValueFactory meridiemFactory = new ListSpinnerValueFactory(meridiemList);
    private final Spinner meridiemSpin = new Spinner(meridiemFactory);
    
    //timebox is public so it can be referenced in gui
    public  HBox timeBox = new HBox();
    
    
    //The constructor for the class formats the nodes used
    public RobertChuckDaronTimeSelector()
    {
        hour.bind(hourBox.valueProperty());
        minute.bind(minuteBox.valueProperty());
        meridiem.bind(meridiemSpin.valueProperty());
        

        // Format am/pm Spinner
        meridiemFactory.setWrapAround(true);
        meridiemSpin.setMaxWidth(58);
        
        //add nodes to timeBox
        timeBox.getChildren().addAll(hourBox,minuteBox,meridiemSpin);
       
    }
    
    
    
    /**Public method IsTimeReady signals that the the time is ready to pass
     * @return Returns true if hour minutes and meridiem is ready to return
     * false otherwise.
     */
    public boolean IsTimeReady()
    {
        Boolean flag;
        
        if ((hour.getValueSafe().isEmpty() || minute.getValueSafe().isEmpty() || meridiem.getValueSafe().isEmpty()))
        {
            flag = false;
        }
        else
        {
            flag = true;
            setTime();
        }
        
        return flag;
    }
    
    
    /**Private setTime method sets the strings
     * hour minute and meridiem
     * 
     */
    
    private void setTime()
    {

        time = hour.getValueSafe();
        time += ":";
        time += minute.getValueSafe();
        time += " ";
        time += meridiem.getValueSafe();
        setMilitaryTime();
    }
    
    private void setMilitaryTime()
    {   
        if(meridiem.getValueSafe().contentEquals("PM"))
        {
            int tempHour = (12 + Integer.parseInt(hour.getValueSafe()));
            militaryTime.concat(String.valueOf(tempHour));
            militaryTime.concat(minute.getValueSafe());
        }
        else
        {
            militaryTime.concat("0");
            militaryTime.concat(hour.getValueSafe());
            militaryTime.concat(minute.getValueSafe());
        }   
    }
    
   public String getConcatTime()
   {
       return time;
   }
   
   public String getMilitaryTime()
   {
       return militaryTime.getValueSafe();
   }
    
}//end class