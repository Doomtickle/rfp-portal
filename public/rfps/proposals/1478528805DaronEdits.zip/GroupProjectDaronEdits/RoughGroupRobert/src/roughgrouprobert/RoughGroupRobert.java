package src.roughgrouprobert;


import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javafx.animation.FadeTransition;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
/**
 *Rough Group project
 *Robert's version
 * Robert Chuck & Daron
 * This file contains the UI only
 */

@SuppressWarnings("restriction")
public class RoughGroupRobert extends Application {
    
    
    /**
    * @param args the command line arguments
    */
    public static void main(String[] args) {
        launch(args);
    }
        //Screen position references
        private double xPos;
        private double yPos;
        //FadeTransition reference
        private FadeTransition ft;
        
        //Stage reference 
        private Stage pStage;
        
        //create Time Selectors
        RobertChuckDaronTimeSelector returnHomeTime = new RobertChuckDaronTimeSelector();
        RobertChuckDaronTimeSelector departTime = new RobertChuckDaronTimeSelector();
        RobertChuckDaronTimeSelector returnTime = new RobertChuckDaronTimeSelector();
        
        //Bound business trip data
        SimpleStringProperty name = new SimpleStringProperty();
        SimpleIntegerProperty days = new SimpleIntegerProperty();
        SimpleIntegerProperty dtime = new SimpleIntegerProperty();
        SimpleIntegerProperty rtime = new SimpleIntegerProperty();
        SimpleIntegerProperty htime = new SimpleIntegerProperty();
        SimpleIntegerProperty airfare = new SimpleIntegerProperty();
        SimpleIntegerProperty miles = new SimpleIntegerProperty();
        SimpleIntegerProperty parkingFees = new SimpleIntegerProperty();
        SimpleIntegerProperty taxiFees = new SimpleIntegerProperty();
        SimpleIntegerProperty hotelFees = new SimpleIntegerProperty();
        SimpleIntegerProperty regFess = new SimpleIntegerProperty();
        Observable breakfast = FXCollections.observableFloatArray();
        Observable lunch = FXCollections.observableFloatArray();
        Observable dinner = FXCollections.observableFloatArray();
        
    @Override
    public void start(Stage primaryStage) {
        //set stage Reference and style
        pStage = primaryStage;
        pStage.initStyle(StageStyle.TRANSPARENT);
        
        //call animated intro scene
        getIntroScene();
        
        //Listen for fade transition to end then call scene1
        ft.setOnFinished(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event)
        {
            getScene1();
        }
        });
    

        
    }//end @override
    /**
     * Intro Scene displays team designation
     */
    public void getIntroScene()
    {
        
        Group root = new Group();
        
        //format prompt label
        Text logo = new Text();
        logo.setText("CODE_HARD");
        logo.setTextOrigin(VPos.TOP);
        logo.setFont(Font.font("Comic Sans MS",FontWeight.BOLD,FontPosture.ITALIC,150));
        //format dropshadow & add to prompt
        DropShadow ds = new DropShadow();
        ds.setColor(Color.CHARTREUSE);
        ds.setSpread(0);
        ds.setRadius(15);
        logo.setEffect(ds);
        //Create Spread Animation
        Timeline timeline = new Timeline();
        timeline.setCycleCount(16);
        timeline.setAutoReverse(true);
        timeline.getKeyFrames().add
                (new KeyFrame(Duration.seconds(3),
                new KeyValue(ds.spreadProperty(),.80,Interpolator.EASE_BOTH)));        
        timeline.play();
        //Create FadeTransition
        ft = new FadeTransition(Duration.seconds(3.5),logo);
        ft.setFromValue(1);
        ft.setToValue(.0);
        ft.play();
        //add prompt to group
        root.getChildren().add(logo);
        //Postion prompt on to scene & format scene
        Scene introScene = new Scene(root);
        introScene.setFill(null);
        
        manageStage(root,introScene);
        pStage.setScene(introScene);
        pStage.centerOnScreen();
        pStage.show();
        
        
        
        ft.setOnFinished(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
           getScene1();
        }
        });
        
        
        
    }
   /**
    * Manage stage allows the window to be moved smoothly
    */
    void manageStage(Group root, Scene scene)
    {   
        
        
        //when mouse button is pressed, save the initial position of screen
        root.setOnMousePressed(e->
        {
            xPos = e.getScreenX() - pStage.getX();
            yPos = e.getScreenY() - pStage.getY();
        });
        
        //when screen is dragged, translate it accordingly
        root.setOnMouseDragged(e ->
        {
            pStage.setX(e.getScreenX() - xPos);
            pStage.setY(e.getScreenY() - yPos);
        });
        
        //set the stage
        pStage.setScene(scene);

    }
    /**
     * Next button provides forward navigation
     */
    Button nextButton(){
        
        ImageView rArrow = new ImageView("src/rightArrow.png");
        Button nextButton = new Button("",rArrow);
        nextButton.setStyle("-fx-background-color: transparent;");
        nextButton.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        nextButton.setTranslateX(792);
        nextButton.setTranslateY(75);
        
        nextButton.setOnMouseEntered(me ->
        {
            nextButton.setEffect(new GaussianBlur(3));
        });
        nextButton.setOnMouseExited(me ->{
            nextButton.setEffect(null);
        });
        nextButton.setOnMousePressed(mp ->{
            nextButton.setTranslateX(795);
        });
        nextButton.setOnMouseReleased(mr->{
            nextButton.setTranslateX(792);
        });
        
        
        
        return nextButton;
        
    }
    
    /**
     * Back Button provides backward Navigation
     */
    Button backButton(){
        
        ImageView lArrow = new ImageView("src/leftArrow.png");
        Button backButton = new Button("",lArrow);
        backButton.setStyle("-fx-background-color: transparent;");
        backButton.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        backButton.setTranslateX(792);
        backButton.setTranslateY(175);
        
        backButton.setOnMouseEntered(me ->
        {
            backButton.setEffect(new GaussianBlur(3));
        });
        backButton.setOnMouseExited(me ->{
            backButton.setEffect(null);
        });
        backButton.setOnMousePressed(mp ->{
            backButton.setTranslateX(795);
        });
        backButton.setOnMouseReleased(mr->{
            backButton.setTranslateX(792);
        });
        
        
        return backButton;
        
    }
    
    /**
     * Exit Button provides APP exiting
     */
    Button exitButton(){
        
        ImageView exit = new ImageView("src/exit.png");
        Button exitButton = new Button("",exit);
        exitButton.setStyle("-fx-background-color: transparent;");
        exitButton.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        exitButton.setTranslateX(792);
        exitButton.setTranslateY(275);
        
        exitButton.setOnMouseEntered(me ->
        {
            exitButton.setEffect(new GaussianBlur(3));
        });
        exitButton.setOnMouseExited(me ->{
            exitButton.setEffect(null);
        });
        exitButton.setOnMousePressed(mp ->{
            exitButton.setTranslateX(795);
        });
        exitButton.setOnMouseReleased(mr->{
            exitButton.setTranslateX(792);
        });
        
        
        return exitButton;
        
    }
    
    /**
     * Scene 1 is the Entry point and title screen of the APP
     */
    void getScene1(){
      
        Group root = new Group();
        Image picture = new Image("src/scene1.png");
        ImageView iv = new ImageView(picture);
        iv.setEffect(new GaussianBlur(3));
        Text prompt = new Text();
        prompt.setText("Trip Reporter Express\n Use the menu on the right to begin.");
        
        prompt.setFill(Color.WHITE);
        prompt.setStroke(Color.BLACK);
        prompt.setFont(Font.font("Helvetica",FontWeight.BOLD,FontPosture.ITALIC,40));
        prompt.setStyle("-fx-stroke: black");
        StackPane spScene1 = new StackPane();
        Button nextButton = nextButton();
        Button backButton = backButton();
        Button exitButton = exitButton();
        spScene1.getChildren().addAll(iv,prompt);
        root.getChildren().addAll(spScene1,nextButton,backButton,exitButton);
        Scene scene = new Scene(root);
        scene.setFill(null);
        manageStage(root,scene);
        pStage.setScene(scene);
        pStage.show();
        
        backButton.setOnAction(a->
        {
            getIntroScene();
        
        });
        
        nextButton.setOnAction(a->
        {
            getName();
        
        });
        exitButton.setOnAction(a->{
        	
        	boolean answer =  ConfirmBox.confirm("Exit the program?", "Are you sure you want \n"
					+ "to exit the program?");
			if (answer == true)
            pStage.close();
        });
        
        
    }
    /**
     *GetName() gets travelers name
     */
    void getName()
    {
        
        
        Button nextButton = nextButton();
        Button backButton = backButton();
        Button exitButton = exitButton();
        
        
        //set a group to hold nodes
        Group root = new Group();
        
        //load image set to imageview
        Image picture = new Image("src/nameTag800x400.png");
        ImageView iv = new ImageView(picture);
            
        StackPane spScene2 = new StackPane(iv);
        spScene2.setBackground(Background.EMPTY);
        
        //text prompt
        Text prompt = new Text("Click The Sceen to enter your name");
        prompt.setFont(Font.font("Helvetica",FontWeight.NORMAL, FontPosture.REGULAR,29));
        prompt.setTextOrigin(VPos.BASELINE);
        spScene2.getChildren().add(prompt);
        
        Text name = new Text("");
        name.setFont(Font.font("Helvetica",FontWeight.NORMAL, FontPosture.REGULAR,29));
        name.setTextOrigin(VPos.BASELINE);
        spScene2.getChildren().addAll(name);
        this.name.bindBidirectional(name.textProperty());
        
        
        //add to group
        root.getChildren().addAll(spScene2,nextButton,backButton,exitButton);
        
        Scene scene = new Scene(root);
        scene.setFill(null);
        
        spScene2.setOnMouseReleased(new EventHandler<MouseEvent>()
        {
            @Override public void handle(MouseEvent me)
            {
                prompt.setVisible(false);
                name.setVisible(true);
                spScene2.requestFocus();
                me.consume();
            }
        });
        spScene2.setOnKeyPressed(new EventHandler<KeyEvent>()
        {
            @Override public void handle(KeyEvent ke)
            {
                String swap = "";
                
              if(ke.getCode().equals(KeyCode.BACK_SPACE))
              {
                  if (!name.getText().isEmpty())
                  {
                    swap = name.getText();
                    swap = swap.substring(0,swap.length()-1);
                  }
                  name.setText(swap);
                  swap = "";
                  ke.consume();
              }
              
              if(ke.getCode().equals(KeyCode.SPACE) 
                && name.getText().isEmpty() == false
                && name.getText().contains(" ") == false)
              {
                  swap = name.getText();
                  swap += " ";
                  name.setText(swap);
                  swap = "";
                  ke.consume();
              }
                  
                
              if (ke.getText().matches("[a-zA-z]") && name.getText().length() < 31)
              { 
                swap = name.getText();
                swap += ke.getText().toUpperCase().trim();
                name.setText(swap);
                swap = "";
                ke.consume();    
              };
              
           if(ke.getCode().equals(KeyCode.ENTER)){ 
              
              if (name.getText().isEmpty())
            {
                prompt.setVisible(true);
                name.setVisible(false);
            }
              
              if(name.getText().isEmpty())
            {
                prompt.setVisible(true);
                prompt.setFill(Paint.valueOf("RED"));
            }
            else 
               getDateTime();
           }
              
            }
        });
       
        
        //handle on mouse removed
        root.setOnMouseExited(a->
        {
            if (name.getText().isEmpty())
            {
                prompt.setVisible(true);
                name.setVisible(false);
            }
        });
        
        nextButton.setOnAction(a->{
            if(name.getText().isEmpty())
            {
                prompt.setVisible(true);
                prompt.setFill(Paint.valueOf("RED"));
            }
            else 
               getDateTime();
        
        });
        
        backButton.setOnAction(a->{
            getScene1();
        });
        exitButton.setOnAction(a->{
        	
        	boolean answer =  ConfirmBox.confirm("Exit the program?", "Are you sure you want \n"
					+ "to exit the program?");
			if (answer == true)
            pStage.close();
        });
        
        
  
        manageStage(root,scene);
        pStage.setScene(scene);
        pStage.show();
         
    }
    
    /**
     *getDateTime() gets travel dates and times
     */
    void getDateTime()
    {
    	
    	
        System.out.println(this.name.toString());
        //setting up depart inputs
        Text departAt = new Text("Pick Your Depart Date and Time: ");
        departAt.setFont(Font.font("Helvetica", FontWeight.BLACK, FontPosture.REGULAR,15));
        
        DatePicker departDate = new DatePicker();
        
       
        
        //add depart inputs to a hbox
        HBox departBox = new HBox();
        departBox.setSpacing(8);
        departBox.getChildren().addAll(departAt,departDate,departTime.timeBox);
        
        
        
        //setting up return inputs 
        Text returnAt = new Text("Pick Your Return Date and Time: ");
        returnAt.setFont(Font.font("Helvetica",FontWeight.BLACK,FontPosture.REGULAR,15));
        
        
        DatePicker returnDate = new DatePicker();
        
        
        //add return inputs to a hbox
        HBox returnBox = new HBox();
        returnBox.setSpacing(8);
        returnBox.getChildren().addAll(returnAt,returnDate,returnTime.timeBox);
        
        //setting up return home inputs
        Text returnHome = new Text("Enter your return home time.");
        returnHome.setFont(Font.font("Helvetica", FontWeight.BLACK, FontPosture.REGULAR,15));
        
        
        
        //add returnhome to a hbox
        HBox returnHomeBox = new HBox();
        returnHomeBox.setSpacing(8);
        returnHomeBox.getChildren().addAll(returnHome,returnHomeTime.timeBox);
    
        StackPane stackpane = new StackPane();
        VBox vbScene3 = new VBox(45);
        vbScene3.setPadding(new Insets(22));
        vbScene3.setBackground(Background.EMPTY);
        stackpane.setBackground(Background.EMPTY);
        Image calendarImage = new Image("src/calendar800x400.jpg");
        ImageView calendarIV = new ImageView(calendarImage);
        stackpane.getChildren().add(calendarIV);
        vbScene3.getChildren().addAll(departBox,returnBox,returnHomeBox);
        stackpane.getChildren().add(vbScene3);
        
        Button nextButton = nextButton();
        Button backButton = backButton();
        Button exitButton = exitButton();
       
        Group root = new Group();
        root.getChildren().addAll(stackpane, nextButton, backButton,exitButton);
       
        Scene scene3 = new Scene(root); 
        scene3.setFill(null);
        manageStage(root,scene3);
        pStage.setScene(scene3);
        
        
        nextButton.setOnAction(a ->{
        	
        	if (departDate.getValue() == null || returnDate.getValue() == null){
        		
        		AlertBox.alert("Error", "Please fill out all fields.");
        		getDateTime();
        	}else{
        	
            dateValid(departDate,returnDate);
            timeValid();
            getAirfare();
        }
            
        });
        
        backButton.setOnAction(a ->{
            getName();
        });
        exitButton.setOnAction(a->{
        	boolean answer =  ConfirmBox.confirm("Exit the program?", "Are you sure you want \n"
					+ "to exit the program?");
			if (answer == true)
            pStage.close();
        });
    }
   
    /**
     *getAirfare() gets any airfare costs
     */
    void getAirfare()
    {
        //nav buttons
        Button nextButton = nextButton();
        Button backButton = backButton();
        Button exitButton = exitButton();
        
        
        //set a group to hold nodes
        Group root = new Group();
        
        //load image set to imageview
        Image picture = new Image("src/airplane800x400.png");
        ImageView iv = new ImageView(picture);
            
        StackPane spScene4 = new StackPane(iv);
        spScene4.setBackground(Background.EMPTY);
        
        VBox vb = new VBox(40);
        vb.setPadding(new Insets(10));
        Text prompt = new Text(" Enter any airfare incurred on you trip.");
        prompt.setFocusTraversable(true);
        prompt.requestFocus();
        prompt.setFont(Font.font("Helvetica",FontWeight.NORMAL, FontPosture.REGULAR,29));
        
        
        
        vb.getChildren().addAll(prompt);
        
        spScene4.getChildren().addAll(vb);
        
        //airfare validation
        TextField airfare = new NumberTextField();  //made a new class to restrict the type of input (only positive integers)
        airfare.setPromptText("$0000.00");
        airfare.setMaxWidth(100);
        airfare.setPrefColumnCount(8);
        vb.getChildren().addAll(airfare);
        
        
        
        root.getChildren().addAll(spScene4,nextButton,backButton,exitButton);
        
        Scene scene4 = new Scene(root); 
        scene4.setFill(null);
        manageStage(root,scene4);
        pStage.setScene(scene4);
        
        nextButton.setOnAction(a->{
        	
        	float valueAirfare = Float.parseFloat(airfare.getText()); //setting our text field to a float
        	
            getCarFees();
        });
        
        backButton.setOnAction(a->{
            getDateTime();
        });
        exitButton.setOnAction(a->{
            pStage.close();
        });
    }
    
    /**
     *getCarFees() gets car associated costs
     */
    void getCarFees()
    {
        //nav buttons
        Button nextButton = nextButton();
        Button backButton = backButton();
        Button exitButton = exitButton();
        
        
        //set a group to hold nodes
        Group root = new Group();
        
        //load image set to imageview
        Image picture = new Image("src/taxi800x400.png");
        ImageView iv = new ImageView(picture);
        
        VBox vb = new VBox();
        vb.setPadding(new Insets(10));
        Text prompt = new Text("Car Fees: Select all that apply to you");
        prompt.setFocusTraversable(true);
        prompt.requestFocus();
        prompt.setFont(Font.font("Helvetica",FontWeight.NORMAL, FontPosture.REGULAR,20));
        prompt.setFill(Color.ANTIQUEWHITE);
        
        
        
        CheckBox cab = new CheckBox("Cab Fare");
        CheckBox personal = new CheckBox("Personal Mileage");
        CheckBox rentalCar = new CheckBox("Rental Car");
        CheckBox parkingFees = new CheckBox("Parking Fees");
        
        cab.setTextFill(Color.ANTIQUEWHITE);
        personal.setTextFill(Color.ANTIQUEWHITE);
        rentalCar.setTextFill(Color.ANTIQUEWHITE);
        parkingFees.setTextFill(Color.ANTIQUEWHITE);
        
        
        vb.getChildren().addAll(prompt, cab, personal, rentalCar, parkingFees);
        
          
        StackPane spScene5 = new StackPane(iv);
        spScene5.setBackground(Background.EMPTY);
        spScene5.getChildren().addAll(vb);
        
       
        root.getChildren().addAll(spScene5,nextButton,backButton,exitButton);
        
        Scene scene5 = new Scene(root); 
        scene5.setFill(null);
        manageStage(root,scene5);
        pStage.setScene(scene5);
        
        
        nextButton.setOnAction(a->{
        	
        	if (cab.isSelected())
        		
        	/*if(personal.isSelected())
        		new PersonalMiles();
        	if(rentalCar.isSelected())
        		new RentalCar();
        	if(parkingFees.isSelected())
        		new parkingFees();
        	else
        		getHotelRegFees();*/
        	
        	getHotelRegFees();
        });
        
        backButton.setOnAction(a->{
            getAirfare();
        });
        exitButton.setOnAction(a->{
        	boolean answer =  ConfirmBox.confirm("Exit the program?", "Are you sure you want \n"
					+ "to exit the program?");
			if (answer == true)
            pStage.close();
        });
    }
    /**
     *getHotelRegFees() gets hotel/registration costs
     */
    void getHotelRegFees()
    {
         //nav buttons
        Button nextButton = nextButton();
        Button backButton = backButton();
        Button exitButton = exitButton();
        
        
        //set a group to hold nodes
        Group root = new Group();
        
        //load image set to imageview
        Image picture = new Image("src/bellagiohotel800x400.png");
        ImageView iv = new ImageView(picture);
        
        
        VBox vb = new VBox(40);
        vb.setPadding(new Insets(10));
        Text prompt = new Text(" Enter any Hotel and registration fees incurred on you trip.");
        prompt.setFocusTraversable(true);
        prompt.requestFocus();
        prompt.setFont(Font.font("Helvetica",FontWeight.NORMAL, FontPosture.REGULAR,29));
        
        vb.getChildren().addAll(prompt);
            
        StackPane spScene6 = new StackPane(iv);
        spScene6.getChildren().addAll(vb);
        spScene6.setBackground(Background.EMPTY);
        
       
        root.getChildren().addAll(spScene6,nextButton,backButton,exitButton);
        
        Scene scene6 = new Scene(root); 
        scene6.setFill(null);
        manageStage(root,scene6);
        pStage.setScene(scene6);
        
        
        nextButton.setOnAction(a->{
            getMeals();
        });
        
        backButton.setOnAction(a->{
            getCarFees();
        });
        exitButton.setOnAction(a->{
            pStage.close();
        });
    }
    
    /**
     *getMeals() gets food costs
     */
    void getMeals()
    {
         //nav buttons
        Button nextButton = nextButton();
        Button backButton = backButton();
        Button exitButton = exitButton();
        
        
        //set a group to hold nodes
        Group root = new Group();
        
        //load image set to imageview
        Image picture = new Image("src/meal800x400.png");
        ImageView iv = new ImageView(picture);
        
        VBox vb = new VBox(40);
        vb.setPadding(new Insets(10));
        Text prompt = new Text(" Enter meal fees incurred on you trip.");
        prompt.setFocusTraversable(true);
        prompt.requestFocus();
        prompt.setFont(Font.font("Helvetica",FontWeight.NORMAL, FontPosture.REGULAR,29));
        prompt.setFill(Color.WHITE);
        prompt.setStroke(Color.BLACK);
        
        vb.getChildren().addAll(prompt);
            
        StackPane spScene7 = new StackPane(iv);
        spScene7.getChildren().addAll(vb);
        spScene7.setBackground(Background.EMPTY);
        
       
        root.getChildren().addAll(spScene7,nextButton,backButton,exitButton);
        
        Scene scene7 = new Scene(root); 
        scene7.setFill(null);
        manageStage(root,scene7);
        pStage.setScene(scene7);
        
        
        nextButton.setOnAction(a->{
            
        });
        
        backButton.setOnAction(a->{
            getHotelRegFees();
        });
        exitButton.setOnAction(a->{
        	boolean answer =  ConfirmBox.confirm("Exit the program?", "Are you sure you want \n"
					+ "to exit the program?");
			if (answer == true)
            pStage.close();
        });
    }
    
    /**
     * dateValid takes depart and return dates and validates them
  for input and that return is after depart
     * @return returns true is dates are valid false otherwise.
     */
    boolean dateValid(DatePicker departD, DatePicker returnD)
    {
        //serves as return flag for method
        
        LocalDate dDate;
        LocalDate rDate;
        long totalDays = 0;
        
        // First Validate the user inputed Dates
        
        //get datepicker items and set to dDate and rDate 
        
        if (departD.getValue().toString().isEmpty() || returnD.getValue().toString().isEmpty()){
        		
        		AlertBox.alert("Error", "Please fill out all fields.");
        		getDateTime();
        	}else{
        	dDate = departD.getValue();
        	 //TO-DO will Throw "java.lang.NullPointerException" error if not program ceases to function properly
        
        
        	rDate = returnD.getValue(); //TO-DO will Throw "java.lang.NullPointerException" error if not program ceases to function properly
        	totalDays = ChronoUnit.DAYS.between(dDate,rDate);
        	}
        /*.between will return the total number of days in case of a trip
        that has the same depart date and return day (1) must be added even though technically
        it is not a whole day but for the apps purpose it is.
        if the return day is before the depart date it will return a (-)
        long value signifying invalid dates*/
        
       
        
        
        
        //validate against a (-)value
        if (totalDays < 0)
           return false;
        else
        {
        	//add (1) to account for the first day of travel in all cases this needs to be done
            totalDays++;
            return true;
            
        }
        /*Test with print statement WORKING
        System.out.println(totalDays+" is the total number of days Traveled.");*/
        
    }
    
    
    /**
     * timeValid checks for valid time values used since time is taken with drop boxes
     * and a spinner this method checks to that the depart and return times do not match
     * if the are on the same day and provides what meals should paid for and that the user
     * indeed did enter three time values.
     *@return returns true if times are valid false otherwise.
     */
    boolean timeValid()
    {
        //return flag for method
        boolean valid;
        
        //Holds times
        String dTime;
        String rTime;
        String hTime;
        
        //validating time
        
       
        
        //check times by using Methods in the class RobertChuckDarTimeSelector.java class
        if (departTime.IsTimeReady()&&returnTime.IsTimeReady()&&returnHomeTime.IsTimeReady())
        {
            dTime = departTime.getConcatTime();
            rTime = returnTime.getConcatTime();
            hTime = returnHomeTime.getConcatTime();
            valid = true;
        }
        else
        {
            dTime = null;
            rTime = null;
            hTime = null;
            valid = false;
        }
            
        //print lines testing time values working properly    
        //System.out.println(dTime);
        //System.out.println(rTime);
        //System.out.println(hTime);
        
        System.out.println(departTime.getMilitaryTime());
        System.out.println(returnTime.getMilitaryTime());
        System.out.println(returnHomeTime.getMilitaryTime());
        
        return valid;
    }
    
}//end class
